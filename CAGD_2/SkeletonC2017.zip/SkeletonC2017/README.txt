This version of cagdkit (cagdkit2008) is adopted to MS VC9 (2008)

It is meant to be a basic graphic utility to be used for graphic UI in
the CAGD course.

It is a C application that contains: 
- The cagd library (the sources are in \src, the header is in \include and
  the library itself is in \Release or \Debug).

- A demo, meant to be an example of using the library, and a basic
  application to start your own programs.

- A short documentation of the library and the demo.

